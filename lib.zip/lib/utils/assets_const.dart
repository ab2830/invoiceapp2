String app_logo="assets/app_log1.png";
String app_background="assets/background.svg";
String bill_svg="assets/bill.svg";
String otp_verify="assets/otp_verify.svg";
String home_icon="assets/home.svg";
String invoice_icon="assets/invoice.svg";
String logout_icon="assets/logout.svg";