import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/searchview_controller.dart';

class SearchviewView extends GetView<SearchviewController> {
  const SearchviewView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SearchviewView'),
        centerTitle: true,
      ),
      body: const Center(
        child: Text(
          'SearchviewView is working',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
