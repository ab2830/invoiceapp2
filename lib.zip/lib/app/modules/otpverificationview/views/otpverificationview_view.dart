import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:freelancing/app/modules/bottamnavigationview/views/bottamnavigationview_view.dart';

import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../../../../utils/assets_const.dart';
import '../../../../utils/colors_const.dart';
import '../../../../utils/common_button.dart';
import '../controllers/otpverificationview_controller.dart';

class OtpverificationviewView extends GetView<OtpverificationviewController> {
  const OtpverificationviewView({Key? key}) : super(key: key);
  @override

  Widget build(BuildContext context) {
    Get.lazyPut(() => OtpverificationviewController());
    return Scaffold(
      body: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                ConstColor.appPrimary1,
                ConstColor.appPrimary2,
              ],
            )),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 76.h,
              ),
              Center(
                  child: SvgPicture.asset(
                    otp_verify,
                    height: 250.h,
                    width: 250.h,
                    fit: BoxFit.cover,
                  )),
              SizedBox(height: 24.h,),
              Text("Verify Your Number",
                  style: GoogleFonts.rubik(
                      fontSize: 34.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white)),
              SizedBox(height: 16.h,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child:
                Text("A text message with code has been sent to +91 9876543210",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.rubik(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white)),
              ),
          SizedBox(height: 16,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Center(
              child: PinCodeTextField(
                length: 6,
                cursorColor: Colors.black,
                keyboardType:TextInputType.number ,



                obscureText: false,
                animationType: AnimationType.fade,
                pinTheme: PinTheme(
                  shape: PinCodeFieldShape.box,
                  selectedFillColor: Colors.white,

                  borderRadius: BorderRadius.circular(10),
                  fieldHeight: 50,
                  fieldWidth: 50,
                  activeFillColor: Colors.white,
                  disabledColor: Colors.transparent,
                  inactiveColor:  Colors.transparent,
                  inactiveFillColor: Colors.white,
                  activeBorderWidth: 1,



                ),
                animationDuration: const Duration(milliseconds: 300),

                enableActiveFill: true,
                controller: controller.otpController,
                onCompleted: (v) {
                  debugPrint("Completed");
                },
                onChanged: (value) {
                 ///
                },
                beforeTextPaste: (text) {
                  return true;
                },
                appContext: context,
              ),
            ),
          ),
              SizedBox(height: 16,),
              Center(
                child: Text("Resend Code",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.rubik(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white)),
              ),
              SizedBox(height: 24.h,),
              Container(
                child: CustomButton(
                  maxHeight: 80.h,
                  color: Colors.white,
                  onPressed: () {
                    Get.offAll(  BottamnavigationviewView());

                    // if (controller.loginFormKey.currentState!.validate()) {
                    //   FocusManager.instance.primaryFocus?.unfocus();
                    //   controller.callLoginApi();
                    // }
                  },
                  title: "Submit",
                  fontWeight: FontWeight.w700,
                  fontSize: 16.sp,
                  textColor: Colors.black,
                ),
              ),


            ],
          ),
        ),
      ),
    );
  }
}