import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:freelancing/app/modules/createbillview/bindings/createbillview_binding.dart';
import 'package:freelancing/app/modules/createbillview/views/createbillview_view.dart';
import 'package:freelancing/app/modules/homeview/views/homeview_view.dart';
import 'package:freelancing/app/modules/profileview/views/profileview_view.dart';
import 'package:freelancing/app/modules/searchview/views/searchview_view.dart';
import 'package:get/get.dart';
import 'package:persistent_bottom_nav_bar/persistent_tab_view.dart';

import '../../../../utils/assets_const.dart';

class BottamnavigationviewController extends GetxController {
  //TODO: Implement BottamnavigationviewController
  PersistentTabController? persistentTabController;

  final count = 0.obs;

  List<PersistentBottomNavBarItem> navBarItems() {
    return [
      PersistentBottomNavBarItem(


        icon:  Icon(FontAwesomeIcons.houseChimney),
        title: "Home",
        activeColorPrimary: Colors.white,
        inactiveColorPrimary: Colors.black

      ),
      PersistentBottomNavBarItem(
          icon:  Icon(FontAwesomeIcons.receipt),
          title: "Invoice",
          activeColorPrimary: Colors.white,
          inactiveColorPrimary: Colors.black

      ),
      PersistentBottomNavBarItem(
          icon:  Icon(FontAwesomeIcons.arrowRightFromBracket),
          title: "Logout",
          activeColorPrimary: Colors.white,
          inactiveColorPrimary: Colors.black


      ),
    ];
  }

  @override
  void onInit() {
    persistentTabController = PersistentTabController(
      initialIndex: 0,
    );
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  List<Widget> screens() {
    return [
      HomeviewView(),
      SearchviewView(),
      CreatebillviewView(),
    ];
  }
}
