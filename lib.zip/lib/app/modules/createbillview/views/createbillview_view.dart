import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:freelancing/utils/colors_const.dart';
import 'package:freelancing/utils/common_text_field.dart';

import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../controllers/createbillview_controller.dart';

class CreatebillviewView extends GetView<CreatebillviewController> {
  const CreatebillviewView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ConstColor.appBgColor,
      appBar: AppBar(
        elevation: 0,
        title:   Text('Create Bill',style: GoogleFonts.dmSans(fontWeight: FontWeight.w700,fontSize: 24.sp,color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      body:SingleChildScrollView(

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
          SizedBox(height: 16.h,),

            Container( width: Get.width,
            color: Colors.white,

              child:Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16,horizontal: 16),
                  child: Row(

                    children: [
                      Expanded(child: CommonTextField()),
                      SizedBox(width: 16.w,),
                      Expanded(child: CommonTextField())
                    ],
                  ),
                ),
              )
            )


        ],),
      )
    );
  }
}
