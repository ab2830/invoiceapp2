import 'package:get/get.dart';

class HomeviewController extends GetxController {
  //TODO: Implement HomeviewController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
