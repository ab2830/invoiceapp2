import 'dart:async';

import 'package:freelancing/app/modules/loginview/views/loginview_view.dart';
import 'package:get/get.dart';

class SplashviewController extends GetxController {
  //TODO: Implement SplashviewController

  final count = 0.obs;
  @override
  void onInit() {
    Timer(const Duration(seconds: 3), () {
      Get.offAll(  LoginviewView());

      //  moveToDashboard();
    });
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
