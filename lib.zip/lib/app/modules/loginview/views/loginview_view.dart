import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:freelancing/app/modules/otpverificationview/views/otpverificationview_view.dart';

import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../utils/assets_const.dart';
import '../../../../utils/colors_const.dart';
import '../../../../utils/common_button.dart';
import '../controllers/loginview_controller.dart';

class LoginviewView extends GetView<LoginviewController> {
  LoginviewView({Key? key}) : super(key: key);
  var loginCon = Get.put(LoginviewController());

  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => LoginviewController());
    return Scaffold(
      body: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            ConstColor.appPrimary1,
            ConstColor.appPrimary2,
          ],
        )),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 76.h,
              ),
              Text(
                "Login Into \nYour Account",
                style: GoogleFonts.rubik(
                    fontSize: 34.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white),
              ),
              const SizedBox(
                height: 16,
              ),
              Text(
                "Sign In Into Your Account",
                style: GoogleFonts.rubik(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w400,
                    color: Colors.white),
              ),
              SizedBox(
                height: 16.h,
              ),
              TextFormField(
                style: GoogleFonts.rubik(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white),
                autofocus: false,
                textInputAction: TextInputAction.done,
                keyboardType: TextInputType.number,
                focusNode: controller.emailFouce,
                controller: controller.emailController,
                decoration: InputDecoration(
                  filled: false,
                  fillColor: Colors.white,
                  isDense: false,
                  disabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white, width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        const BorderSide(color: Colors.white, width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white, width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  isCollapsed: false,
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1.5),
                      borderRadius: BorderRadius.circular(10)),
                  hintText: "Mobile Number",
                  hintStyle: GoogleFonts.rubik(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),
                ),
                onFieldSubmitted: (r) {
                  controller.emailFouce.unfocus();
                  FocusScope.of(context).requestFocus(controller.passwordFouce);
                },
                // validator: (value) {
                //   if (value!.isEmpty) {
                //     return emailErrorText;
                //   } else if (value.trim().isEmpty) {
                //     return emailErrorText;
                //   } else if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                //     return valideEmailErrorText;
                //   } else {
                //     return null;
                //   }
                // },
              ),
              const SizedBox(
                height: 20,
              ),
              TextFormField(
                style: GoogleFonts.rubik(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white),
                focusNode: controller.passwordFouce,
                controller: controller.passwordController,
                keyboardType: TextInputType.visiblePassword,
                obscureText: true,
                decoration: InputDecoration(
                    filled: false,
                    fillColor: Colors.white,
                    isDense: false,
                    isCollapsed: false,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    hintText: "Password",
                    hintStyle: GoogleFonts.rubik(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w400,
                        color: Colors.white)),
                //   validator: (value) {
                //     if (value!.isEmpty) {
                //       return passwordErrorText;
                //     } else if (value.trim().isEmpty) {
                //       return passwordErrorText;
                //     } else {
                //       return null;
                //     }
                //   },
                // ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                child: CustomButton(
                  maxHeight: 80.h,
                  color: Colors.white,
                  onPressed: () {
                    Get.offAll(OtpverificationviewView());
                    // if (controller.loginFormKey.currentState!.validate()) {
                    //   FocusManager.instance.primaryFocus?.unfocus();
                    //   controller.callLoginApi();
                    // }
                  },
                  title: "Log in",
                  fontWeight: FontWeight.w700,
                  fontSize: 16.sp,
                  textColor: Colors.black,
                ),
              ),
              SizedBox(
                height: 40.h,
              ),
              Center(
                  child: SvgPicture.asset(
                bill_svg,
                height: 150.h,
                width: 150.h,
              )),
            ],
          ),
        ),
      ),
    );
  }
}
