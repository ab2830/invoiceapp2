part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const SPLASHVIEW = _Paths.SPLASHVIEW;
  static const LOGINVIEW = _Paths.LOGINVIEW;
  static const OTPVERIFICATIONVIEW = _Paths.OTPVERIFICATIONVIEW;
  static const BOTTAMNAVIGATIONVIEW = _Paths.BOTTAMNAVIGATIONVIEW;
  static const PROFILEVIEW = _Paths.PROFILEVIEW;
  static const SEARCHVIEW = _Paths.SEARCHVIEW;
  static const HOMEVIEW = _Paths.HOMEVIEW;
  static const CREATEBILLVIEW = _Paths.CREATEBILLVIEW;
}

abstract class _Paths {
  _Paths._();
  static const SPLASHVIEW = '/splashview';
  static const LOGINVIEW = '/loginview';
  static const OTPVERIFICATIONVIEW = '/otpverificationview';
  static const BOTTAMNAVIGATIONVIEW = '/bottamnavigationview';
  static const PROFILEVIEW = '/profileview';
  static const SEARCHVIEW = '/searchview';
  static const HOMEVIEW = '/homeview';
  static const CREATEBILLVIEW = '/createbillview';
}
